/* �O���t�B�b�N�����֌W */

#include "bootpack.h"

#include<math.h>


void init_palette(void)
{
	static unsigned char table_rgb[16 * 3] = {
		0x00, 0x00, 0x00,	/*  0:�K */
		0xff, 0x00, 0x00,	/*  1:��? */
		0x00, 0xff, 0x00,	/*  2:��? */
		0xff, 0xff, 0x00,	/*  3:���� */
		0x00, 0x00, 0xff,	/*  4:��? */
		0xff, 0x00, 0xff,	/*  5:���� */
		0x00, 0xff, 0xff,	/*  6:��? */
		0xff, 0xff, 0xff,	/*  7:�� */
		0xc6, 0xc6, 0xc6,	/*  8:���D */
		0x84, 0x00, 0x00,	/*  9:��? */
		0x00, 0x84, 0x00,	/* 10:��? */
		0x84, 0x84, 0x00,	/* 11:�É� */
		0x00, 0x00, 0x84,	/* 12:�Ð� */
		0x84, 0x00, 0x84,	/* 13:�Î� */
		0x00, 0x84, 0x84,	/* 14:���? */
		0x84, 0x84, 0x84	/* 15:�ÊD */
	};
	unsigned char table2[216 * 3];
	int r, g, b;
	set_palette(0, 15, table_rgb);
	for (b = 0; b < 6; b++) {
		for (g = 0; g < 6; g++) {
			for (r = 0; r < 6; r++) {
				table2[(r + g * 6 + b * 36) * 3 + 0] = r * 51;
				table2[(r + g * 6 + b * 36) * 3 + 1] = g * 51;
				table2[(r + g * 6 + b * 36) * 3 + 2] = b * 51;
			}
		}
	}
	set_palette(16, 231, table2);
	return;
}

void set_palette(int start, int end, unsigned char *rgb)
{
	int i, eflags;
	eflags = io_load_eflags();	
	io_cli(); 					
	io_out8(0x03c8, start);
	for (i = start; i <= end; i++) {
		io_out8(0x03c9, rgb[0] / 4);
		io_out8(0x03c9, rgb[1] / 4);
		io_out8(0x03c9, rgb[2] / 4);
		rgb += 3;
	}
	io_store_eflags(eflags);	
	return;
}

void boxfill8(unsigned char *vram, int xsize, unsigned char c, int x0, int y0, int x1, int y1)
{
	int x, y;
	for (y = y0; y <= y1; y++) {
		for (x = x0; x <= x1; x++)
			vram[y * xsize + x] = c;
	}
	return;
}

void boxfill1(unsigned char *vram, int xsize, unsigned char c, int x0, int y0, int x1, int y1)
{
	int x, y, i = 0;
	for (y = y0; y <= y1; y++) {
		for (x = x0; x <= x1; x++)
			i++;
			if ((i % 2) == 1) {
				vram[y * xsize + x] = c;
			} else {
				vram[y * xsize + x] = vram[y * xsize + x];
			}
	}
	return;
}

void init_screen8(char *vram, int x, int y)
{
	boxfill8(vram, x, 136,  0,     0,      x -  1, y - 29);
	boxfill8(vram, x, COL8_C6C6C6,  0,     y - 28, x -  1, y - 28);
	boxfill8(vram, x, COL8_FFFFFF,  0,     y - 27, x -  1, y - 27);
	boxfill8(vram, x, COL8_C6C6C6,  0,     y - 26, x -  1, y -  1);

	boxfill8(vram, x, COL8_FFFFFF,  3,     y - 24, 59,     y - 24);
	boxfill8(vram, x, COL8_FFFFFF,  2,     y - 24,  2,     y -  4);
	boxfill8(vram, x, COL8_848484,  3,     y -  4, 59,     y -  4);
	boxfill8(vram, x, COL8_848484, 59,     y - 23, 59,     y -  5);
	boxfill8(vram, x, COL8_000000,  2,     y -  3, 59,     y -  3);
	boxfill8(vram, x, COL8_000000, 60,     y - 24, 60,     y -  3);

	boxfill8(vram, x, COL8_848484, x - 210, y - 24, x -  4, y - 24);
	boxfill8(vram, x, COL8_848484, x - 210, y - 23, x - 210, y -  4);
	boxfill8(vram, x, COL8_FFFFFF, x - 210, y -  3, x -  4, y -  3);
	boxfill8(vram, x, COL8_FFFFFF, x -  3, y - 24, x -  3, y -  3);
	//my computer

	boxfill8(vram, x, COL8_C6C6C6, 10, 25, 45, 45);
	boxfill8(vram, x, COL8_00FFFF, 12, 27, 43, 43);
	boxfill8(vram, x, COL8_C6C6C6, 22, 45, 32, 55);
	boxfill8(vram, x, COL8_C6C6C6, 12, 55, 43, 57);
	
	putfonts8_asc(vram, x, 20, 60, COL8_000000, "my");
	putfonts8_asc(vram, x, 5, 76, COL8_000000, "computer");
	putfonts8_asc(vram, x, 19, 59, COL8_FFFFFF, "my");
	putfonts8_asc(vram, x, 4, 75, COL8_FFFFFF, "computer");

	
	//note

	boxfill8(vram, x, COL8_C6C6C6, 10, 280, 33, 310);
	putfonts8_asc(vram, x, 8, 280, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 285, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 290, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 295, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 300, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 7, 320, COL8_000000, "note");
	putfonts8_asc(vram, x, 6, 319, COL8_FFFFFF, "note");

	//cmd

	boxfill8(vram, x, COL8_848484, 10, 99, 43, 123);
	boxfill8(vram, x, COL8_000000, 10, 100, 43, 123);
	putfonts8_asc(vram, x, 11, 102, COL8_FFFFFF, ">_");
	putfonts8_asc(vram, x, 10, 126, COL8_000000, "cmd");
	putfonts8_asc(vram, x, 9, 125, COL8_FFFFFF, "cmd");

	//VMware

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	boxfill8(vram, x, COL8_FF0000, 10, 160, 12, 182);
	boxfill8(vram, x, COL8_FF0000, 26, 160, 28, 182);
	boxfill8(vram, x, COL8_FF0000, 10, 180, 28, 182);
	
	boxfill8(vram, x, 203, 15, 155, 30, 157);
	boxfill8(vram, x, 203, 15, 155, 17, 177);
	boxfill8(vram, x, 203, 30, 155, 32, 177);
	boxfill8(vram, x, 203, 15, 175, 30, 177);

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	
	putfonts8_asc(vram, x, 5, 186, COL8_000000, "VMware");
	putfonts8_asc(vram, x, 4, 185, COL8_FFFFFF, "VMware");

	//game

	boxfill8(vram, x, COL8_00FF00, 10, 210, 40, 240);
	putfonts8_asc(vram, x, 12, 210, COL8_FF0000, "p l");
	putfonts8_asc(vram, x, 12, 224, COL8_FF0000, "a y");
	putfonts8_asc(vram, x, 6, 250, COL8_000000, "game");
	putfonts8_asc(vram, x, 5, 249, COL8_FFFFFF, "game");



	//DOSBox
	
	boxfill8(vram, x, COL8_848400, 10, 340, 40, 375);
	putfonts8_asc(vram, x, 12, 342, COL8_FFFF00, "DOS");
	putfonts8_asc(vram, x, 12, 358, COL8_FFFF00, "BOX");
	putfonts8_asc(vram, x, 6, 380, COL8_000000, "DOSBox");
	putfonts8_asc(vram, x, 5, 379, COL8_FFFFFF, "DOSBox");

	//python

	boxfill8(vram, x, COL8_FFFF00, 21, 405, 35, 415);
	boxfill8(vram, x, COL8_FFFF00, 21, 416, 30, 420);
	boxfill8(vram, x, COL8_0000FF, 20, 400, 30, 404);
	boxfill8(vram, x, COL8_0000FF, 15, 405, 30, 410);
	boxfill8(vram, x, COL8_0000FF, 15, 410, 20, 415);
	boxfill8(vram, x, COL8_FFFFFF, 22, 402, 22, 402);
	boxfill8(vram, x, COL8_FFFFFF, 28, 418, 28, 418);
	putfonts8_asc(vram, x, 6, 430, COL8_000000, "python");
	putfonts8_asc(vram, x, 5, 429, COL8_FFFFFF, "python");


	boxfill8(vram, x, COL8_000000, 75, 25, 115, 62);
	putfonts8_asc(vram, x, 80, 26, COL8_FF00FF, "Chat");
	putfonts8_asc(vram, x, 82, 45, COL8_FF00FF, "GPT");
	putfonts8_asc(vram, x, 70, 65, COL8_000000, "ChatGPT");
	putfonts8_asc(vram, x, 69, 64, COL8_FFFFFF, "ChatGPT");

	boxfill8(vram, x, COL8_000000, 75, 125, 115, 162);
	putfonts8_asc(vram, x, 80, 126, COL8_FF00FF, "func");
	putfonts8_asc(vram, x, 82, 145, COL8_FF00FF, "sin");
	putfonts8_asc(vram, x, 70, 165, COL8_000000, "func");
	putfonts8_asc(vram, x, 69, 164, COL8_FFFFFF, "func");


	init_mychar1(vram, x, y);

	
	putfonts8_asc(vram, x, 10, y - 20, COL8_000000, "Start");
	putfonts8_asc(vram, x, 100, y - 20, COL8_000000, "WorkOS");


return;
}

void init_mychar1(char *vram, int x, int y) {
	putfonts8_asc(vram, x, x - 150, y - 66, COL8_FFFFFF, "   made in China");
	putfonts8_asc(vram, x, x - 150, y - 50, COL8_FFFFFF, "Work system ver2");
	return;
}


void init_screen4(char *vram, int x, int y)
{
int *fat;
unsigned char c;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
boxfill8(vram, x, COL8_FFFFFF,  0,     0,      x -  1, y - 29);
fat = (int *) memman_alloc_4k(memman, 4 * 2880);
file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
mac_read_picture(fat, vram, x, y);
memman_free_4k(memman, (int) fat, 4 * 2880);
boxfill8(vram, x, COL8_000000, 0, 28, x - 1, 28);
boxfill8(vram, x, COL8_848484, 0, 27, x - 1, 27);
//boxfill8(vram, x, COL8_00FFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_848484, 3, 24, 59, 24);
boxfill8(vram, x, COL8_848484, 2, 24, 2, 4);
boxfill8(vram, x, COL8_000000, 3, 4, 59, 4);
boxfill8(vram, x, COL8_000000, 59, 23, 59, 5);
boxfill8(vram, x, COL8_000000, 2, 3, 59, 3);
boxfill8(vram, x, COL8_000000, 60, 24, 60, 3);
boxfill8(vram, x, COL8_000000, x - 47, 24, x - 4, 24);
boxfill8(vram, x, COL8_000000, x - 47, 23, x - 47, 4);
boxfill8(vram, x, COL8_848484, x - 47, 3, x - 4, 3);
boxfill8(vram, x, COL8_848484, x - 3, 24, x - 3, 3);

boxfill8(vram, x, COL8_C6C6C6, 240, y - 50, x - 240, y - 2);

boxfill8(vram, x, COL8_848400, 255, y - 45, 278, y - 16);
boxfill8(vram, x, COL8_FFFFFF, 260, y - 40, 288, y - 16);
boxfill8(vram, x, COL8_FFFF00, 255, y - 35, 293, y - 16);

	putfonts8_asc(vram, x, 10, 4, COL8_848484, "Start    Language:English | Area:China | MacOS");
	//my computer
/*
	boxfill8(vram, x, COL8_C6C6C6, 10, 15, 45, 35);
	boxfill8(vram, x, COL8_00FFFF, 12, 17, 43, 33);
	boxfill8(vram, x, COL8_C6C6C6, 22, 35, 32, 45);
	boxfill8(vram, x, COL8_C6C6C6, 12, 45, 43, 47);
	
	putfonts8_asc(vram, x, 20, 50, COL8_000000, "my");
	putfonts8_asc(vram, x, 5, 66, COL8_000000, "computer");

*/
	//note

	boxfill8(vram, x, COL8_C6C6C6, 10, 40, 33, 70);
	putfonts8_asc(vram, x, 8, 40, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 45, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 50, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 55, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 60, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 7, 70, COL8_000000, "note");

	//cmd

	boxfill8(vram, x, COL8_848484, 10, 99, 43, 123);
	boxfill8(vram, x, COL8_000000, 10, 100, 43, 123);
	putfonts8_asc(vram, x, 11, 102, COL8_FFFFFF, ">_");
	putfonts8_asc(vram, x, 10, 126, COL8_000000, "cmd");

	//VMware

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	boxfill8(vram, x, COL8_FF0000, 10, 160, 12, 182);
	boxfill8(vram, x, COL8_FF0000, 26, 160, 28, 182);
	boxfill8(vram, x, COL8_FF0000, 10, 180, 28, 182);
	
	boxfill8(vram, x, 203, 15, 155, 30, 157);
	boxfill8(vram, x, 203, 15, 155, 17, 177);
	boxfill8(vram, x, 203, 30, 155, 32, 177);
	boxfill8(vram, x, 203, 15, 175, 30, 177);

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	
	putfonts8_asc(vram, x, 5, 186, COL8_000000, "VMware");

	putfonts8_asc(vram, x, 10, y - 20, COL8_FFFFFF, "return");

	//game

	boxfill8(vram, x, COL8_00FF00, 10, 210, 40, 240);
	putfonts8_asc(vram, x, 6, 250, COL8_000000, "game");


return;
}

void VM_init_screen8(char *vram, int x, int y)
{
int *fat;
unsigned char c;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
boxfill8(vram, x, COL8_FFFFFF,  0,     0,      x -  1, y - 29);
fat = (int *) memman_alloc_4k(memman, 4 * 2880);
file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
VM_read_picture(fat, vram, x, y);
memman_free_4k(memman, (int) fat, 4 * 2880);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);

	//VMware
	boxfill8(vram, x, COL8_FF0000, 10, 10, 28, 12);
	boxfill8(vram, x, COL8_FF0000, 10, 10, 12, 32);
	boxfill8(vram, x, COL8_FF0000, 26, 10, 28, 32);
	boxfill8(vram, x, COL8_FF0000, 10, 30, 28, 32);
	
	boxfill8(vram, x, 203, 15, 5, 30, 7);
	boxfill8(vram, x, 203, 15, 5, 17, 27);
	boxfill8(vram, x, 203, 30, 5, 32, 27);
	boxfill8(vram, x, 203, 15, 25, 30, 27);

	boxfill8(vram, x, COL8_FF0000, 10, 10, 28, 12);
	
	putfonts8_asc(vram, x, 50, 10, COL8_000000, "VMware");

	boxfill8(vram, x, COL8_FF0000, x - 50, 10, x - 5, 26);
	putfonts8_asc(vram, x, x - 50, 10, COL8_FFFFFF, "-|O|X");
	boxfill8(vram, x, COL8_000000, 0, 35, x - 1, 35);
	
	//boxfill8(vram, x, COL8_000000, 140, 160, 250, 180);
	boxfill8(vram, x, COL8_000000, 400, 200, 1010, 650);

	
	putfonts8_asc(vram, x, 130, 260, COL8_000000, "ABOUT  :");
	putfonts8_asc(vram, x, 130, 280, COL8_000000, "\nSYSTEM:");
	putfonts8_asc(vram, x, 130, 296, COL8_000000, "\nWindows(WorkOS version)");
	putfonts8_asc(vram, x, 130, 320, COL8_000000, "\nFROM  :");
	putfonts8_asc(vram, x, 130, 336, COL8_000000, "\nMicrosoft(or Lin Honghan)");
	putfonts8_asc(vram, x, 130, 360, COL8_000000, "\nCPU   :1");
	putfonts8_asc(vram, x, 130, 380, COL8_000000, "......");
	putfonts8_asc(vram, x, 130, 400, COL8_000000, "\nOTHER :");
	putfonts8_asc(vram, x, 130, 416, COL8_000000, "\nWindows cracked version");

	putfonts8_asc(vram, x, 10, y - 20, COL8_00FFFF, "Start");

return;
}


void file_init_screen8(char *vram, int x, int y, unsigned int memtotal)
{
int *fat;
unsigned char c;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
boxfill8(vram, x, COL8_FFFFFF,  0,     0,      x -  1, y - 29);
fat = (int *) memman_alloc_4k(memman, 4 * 2880);
file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
file_read_picture(fat, vram, x, y);
memman_free_4k(memman, (int) fat, 4 * 2880);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);


	boxfill8(vram, x, COL8_FF0000, x - 50, 10, x - 5, 26);
	putfonts8_asc(vram, x, x - 50, 10, COL8_FFFFFF, "-|O|X");
	

	putfonts8_asc(vram, x, 10, y - 20, COL8_00FFFF, "Start");

	struct FILEINFO *finfo = (struct FILEINFO *) (ADR_DISKIMG + 0x002600);
    int i, j;
    char s[30];
	int f_times=0;
	int n=100;
	char folder[10][30]={"WorkOS\\", "System\\", "Downloads\\"};
    // ????? f_times ????????
    if (f_times == 0) {
        putfonts8_asc(vram, x, 10, n, COL8_000000, "Folder:WorkOS\\");
    } else if (f_times == 1) {
        putfonts8_asc(vram, x, 10, n, COL8_000000, "Folder:WorkOS\\System\\\n");
    } else if (f_times == 2) {
        putfonts8_asc(vram, x, 10, n, COL8_000000, "Folder:WorkOS\\Downloads\\\n");
    } else {
        // ?????????
        char folderName[30];
        sprintf(folderName, "Folder:%s", folder[f_times]);
		putfonts8_asc(vram, x, n, 10, COL8_000000, folderName);
    }

    for (i = 0; i < 224; i++) {
        if (finfo[i].name[0] == 0x00) {
            break;
        }
        if (finfo[i].name[0]!= 0xe5) {
            if ((finfo[i].type & 0x18) == 0) {
                sprintf(s, "filename.ext   %7d", finfo[i].size);
                for (j = 0; j < 8; j++) {
                    s[j] = finfo[i].name[j];
                }
                s[9] = finfo[i].ext[0];
                s[10] = finfo[i].ext[1];
                s[11] = finfo[i].ext[2];

                putfonts8_asc(vram, x, 10, n+17*(i+1), COL8_000000, s);
				/*
				my_file_name[i][0] = finfo[i].ext[0];
				my_file_name[i][1] = finfo[i].ext[1];
				my_file_name[i][2] = finfo[i].ext[2];
				my_file_name2[i][0] = finfo[i].name[0];
				my_file_name2[i][1] = finfo[i].name[1];
				my_file_name2[i][2] = finfo[i].name[2];
				my_file_name2[i][3] = finfo[i].name[3];
				my_file_name2[i][4] = finfo[i].name[4];
				my_file_name2[i][5] = finfo[i].name[5];
				my_file_name2[i][6] = finfo[i].name[6];
				my_file_name2[i][7] = finfo[i].name[7];*/
            }
			if ((finfo[i].type & 0x10) == 0x10) {
                // ??????????????
                sprintf(s, "dirname      <DIR>", finfo[i].name);
                putfonts8_asc(vram, x, 10, n+17*(i+1), COL8_000000, s);
            }
        }
    }
	char s1[60];
	char s2[60];
	sprintf(s1, "total   %dMB", memtotal / (1024 * 1024));
	sprintf(s2, "free %dKB", memman_total(memman) / 1024);
	putfonts8_asc(vram, x, 400, 100, COL8_000000, s1);
	putfonts8_asc(vram, x, 400, 117, COL8_000000, s2);

return;
}

void win_init_screen8(char *vram, int x, int y)
{
int *fat;
unsigned char c;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
boxfill8(vram, x, COL8_FFFFFF,  0,     0,      x -  1, y - 29);
fat = (int *) memman_alloc_4k(memman, 4 * 2880);
file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
win_read_picture(fat, vram, x, y);
memman_free_4k(memman, (int) fat, 4 * 2880);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
//boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);
	//note
	boxfill8(vram, x, COL8_C6C6C6, 10, 40, 33, 70);
	putfonts8_asc(vram, x, 8, 40, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 45, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 50, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 55, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 60, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 7, 70, COL8_000000, "note");
	//cmd
	boxfill8(vram, x, COL8_848484, 10, 99, 43, 123);
	boxfill8(vram, x, COL8_000000, 10, 100, 43, 123);
	putfonts8_asc(vram, x, 11, 102, COL8_FFFFFF, ">_");
	putfonts8_asc(vram, x, 10, 126, COL8_000000, "cmd");
	//VMware
	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	boxfill8(vram, x, COL8_FF0000, 10, 160, 12, 182);
	boxfill8(vram, x, COL8_FF0000, 26, 160, 28, 182);
	boxfill8(vram, x, COL8_FF0000, 10, 180, 28, 182);
	
	boxfill8(vram, x, 203, 15, 155, 30, 157);
	boxfill8(vram, x, 203, 15, 155, 17, 177);
	boxfill8(vram, x, 203, 30, 155, 32, 177);
	boxfill8(vram, x, 203, 15, 175, 30, 177);

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	
	putfonts8_asc(vram, x, 5, 186, COL8_000000, "VMware");

	putfonts8_asc(vram, x, 10, y - 20, COL8_00FFFF, "Start");

	
	//VMware
	
	boxfill8(vram, x, COL8_FFFFFF, 0, 0, x - 1, 35);

	boxfill8(vram, x, COL8_FF0000, 10, 10, 28, 12);
	boxfill8(vram, x, COL8_FF0000, 10, 10, 12, 32);
	boxfill8(vram, x, COL8_FF0000, 26, 10, 28, 32);
	boxfill8(vram, x, COL8_FF0000, 10, 30, 28, 32);
	
	boxfill8(vram, x, 203, 15, 5, 30, 7);
	boxfill8(vram, x, 203, 15, 5, 17, 27);
	boxfill8(vram, x, 203, 30, 5, 32, 27);
	boxfill8(vram, x, 203, 15, 25, 30, 27);

	boxfill8(vram, x, COL8_FF0000, 10, 10, 28, 12);
	
	putfonts8_asc(vram, x, 50, 10, COL8_000000, "VMware-Windows(running)");

	boxfill8(vram, x, COL8_FF0000, x - 50, 10, x - 5, 26);
	putfonts8_asc(vram, x, x - 250, 10, COL8_00FFFF, "power off");
	putfonts8_asc(vram, x, x - 50, 10, COL8_FFFFFF, "-|O|X");
	boxfill8(vram, x, COL8_000000, 0, 35, x - 1, 35);

return;
}


int mac_read_picture(int *fat, char *vram, int x, int y)
{
int i, j, x0, y0, fsize, info[4];
unsigned char *filebuf, r, g, b;
struct RGB *picbuf;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
struct FILEINFO *finfo;
struct DLL_STRPICENV *env;
finfo = file_search("desktop4.jpg", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
if (finfo == 0) {
return -1;
}
fsize = finfo->size;
filebuf = (unsigned char *) memman_alloc_4k(memman, fsize);
filebuf = file_loadfile2(finfo->clustno, &fsize, fat);
env = (struct DLL_STRPICENV *) memman_alloc_4k(memman, sizeof(struct DLL_STRPICENV));
info_JPEG(env, info, fsize, filebuf);
picbuf = (struct RGB *) memman_alloc_4k(memman, info[2] * info[3] * sizeof(struct RGB));
decode0_JPEG(env, fsize, filebuf, 4, (unsigned char *) picbuf, 0);
x0 = (int) ((x - info[2]) / 2);
y0 = (int) ((y - info[3]) / 2);
for (i = 0; i < info[3]; i++) {
for (j = 0; j < info[2]; j++) {
r = picbuf[i * info[2] + j].r;
g = picbuf[i * info[2] + j].g;
b = picbuf[i * info[2] + j].b;
vram[(y0 + i) * x + (x0 + j)] = rgb2pal(r, g, b, j, i, binfo->vmode);
}
}
memman_free_4k(memman, (int) filebuf, fsize);
memman_free_4k(memman, (int) picbuf , info[2] * info[3] * sizeof(struct RGB));
memman_free_4k(memman, (int) env , sizeof(struct DLL_STRPICENV));
return 0;
}

int VM_read_picture(int *fat, char *vram, int x, int y)
{
int i, j, x0, y0, fsize, info[4];
unsigned char *filebuf, r, g, b;
struct RGB *picbuf;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
struct FILEINFO *finfo;
struct DLL_STRPICENV *env;
finfo = file_search("VMware.jpg", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
if (finfo == 0) {
return -1;
}
fsize = finfo->size;
filebuf = (unsigned char *) memman_alloc_4k(memman, fsize);
filebuf = file_loadfile2(finfo->clustno, &fsize, fat);
env = (struct DLL_STRPICENV *) memman_alloc_4k(memman, sizeof(struct DLL_STRPICENV));
info_JPEG(env, info, fsize, filebuf);
picbuf = (struct RGB *) memman_alloc_4k(memman, info[2] * info[3] * sizeof(struct RGB));
decode0_JPEG(env, fsize, filebuf, 4, (unsigned char *) picbuf, 0);
x0 = (int) ((x - info[2]) / 2);
y0 = (int) ((y - info[3]) / 2);
for (i = 0; i < info[3]; i++) {
for (j = 0; j < info[2]; j++) {
r = picbuf[i * info[2] + j].r;
g = picbuf[i * info[2] + j].g;
b = picbuf[i * info[2] + j].b;
vram[(y0 + i) * x + (x0 + j)] = rgb2pal(r, g, b, j, i, binfo->vmode);
}
}
memman_free_4k(memman, (int) filebuf, fsize);
memman_free_4k(memman, (int) picbuf , info[2] * info[3] * sizeof(struct RGB));
memman_free_4k(memman, (int) env , sizeof(struct DLL_STRPICENV));
return 0;
}


int file_read_picture(int *fat, char *vram, int x, int y)
{
int i, j, x0, y0, fsize, info[4];
unsigned char *filebuf, r, g, b;
struct RGB *picbuf;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
struct FILEINFO *finfo;
struct DLL_STRPICENV *env;
finfo = file_search("file.jpg", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
if (finfo == 0) {
return -1;
}
fsize = finfo->size;
filebuf = (unsigned char *) memman_alloc_4k(memman, fsize);
filebuf = file_loadfile2(finfo->clustno, &fsize, fat);
env = (struct DLL_STRPICENV *) memman_alloc_4k(memman, sizeof(struct DLL_STRPICENV));
info_JPEG(env, info, fsize, filebuf);
picbuf = (struct RGB *) memman_alloc_4k(memman, info[2] * info[3] * sizeof(struct RGB));
decode0_JPEG(env, fsize, filebuf, 4, (unsigned char *) picbuf, 0);
x0 = (int) ((x - info[2]) / 2);
y0 = (int) ((y - info[3]) / 2);
for (i = 0; i < info[3]; i++) {
for (j = 0; j < info[2]; j++) {
r = picbuf[i * info[2] + j].r;
g = picbuf[i * info[2] + j].g;
b = picbuf[i * info[2] + j].b;
vram[(y0 + i) * x + (x0 + j)] = rgb2pal(r, g, b, j, i, binfo->vmode);
}
}
memman_free_4k(memman, (int) filebuf, fsize);
memman_free_4k(memman, (int) picbuf , info[2] * info[3] * sizeof(struct RGB));
memman_free_4k(memman, (int) env , sizeof(struct DLL_STRPICENV));
return 0;
}

int win_read_picture(int *fat, char *vram, int x, int y)
{
int i, j, x0, y0, fsize, info[4];
unsigned char *filebuf, r, g, b;
struct RGB *picbuf;
struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
struct FILEINFO *finfo;
struct DLL_STRPICENV *env;
finfo = file_search("desktop2.jpg", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
if (finfo == 0) {
return -1;
}
fsize = finfo->size;
filebuf = (unsigned char *) memman_alloc_4k(memman, fsize);
filebuf = file_loadfile2(finfo->clustno, &fsize, fat);
env = (struct DLL_STRPICENV *) memman_alloc_4k(memman, sizeof(struct DLL_STRPICENV));
info_JPEG(env, info, fsize, filebuf);
picbuf = (struct RGB *) memman_alloc_4k(memman, info[2] * info[3] * sizeof(struct RGB));
decode0_JPEG(env, fsize, filebuf, 4, (unsigned char *) picbuf, 0);
x0 = (int) ((x - info[2]) / 2);
y0 = (int) ((y - info[3]) / 2);
for (i = 0; i < info[3]; i++) {
for (j = 0; j < info[2]; j++) {
r = picbuf[i * info[2] + j].r;
g = picbuf[i * info[2] + j].g;
b = picbuf[i * info[2] + j].b;
vram[(y0 + i) * x + (x0 + j)] = rgb2pal(r, g, b, j, i, binfo->vmode);
}
}
memman_free_4k(memman, (int) filebuf, fsize);
memman_free_4k(memman, (int) picbuf , info[2] * info[3] * sizeof(struct RGB));
memman_free_4k(memman, (int) env , sizeof(struct DLL_STRPICENV));
return 0;
}

unsigned short rgb2pal(int r, int g, int b, int x, int y, int cb)
{
if (cb == 8) {
static int table[4] = { 3, 1, 0, 2 };
int i;
x &= 1; /* ������?���?�H */
y &= 1;
i = table[x + y * 2];
r = (r * 21) / 256;
g = (g * 21) / 256;
b = (b * 21) / 256;
r = (r + i) / 4;
g = (g + i) / 4;
b = (b + i) / 4;
return((unsigned short) (16 + r + g * 6 + b * 36));
} else {
return((unsigned short) (((r << 8) & 0xf800) | ((g << 3) & 0x07e0) | (b >> 3)));
}
}

double extractAndEvaluateFunction(char *temp, double xValue, int size) {
	double result;
    if (strncmp(temp, "sqrt(x)", 7) == 0) {
        result = size*sqrt(xValue/size);
    } else if (strncmp(temp, "sqrt(10000-x*x)", 6) == 0) {
        result = sqrt(size*size-xValue * xValue);
    } else if (strncmp(temp, "sin(x)", 6) == 0) {
        result = size*sin(xValue/size);
    } else if (strncmp(temp, "cos(x)", 6) == 0) {
        result = size*cos(xValue/size);
    } else if (strncmp(temp, "x*x", 3) == 0) {
        result = xValue * xValue;
    } else {
        result = 0;
    }


    return result;
}
void drawElementaryFunctionGraph2(unsigned char *vram, int xsize, int c1, int xMin, int xMax, int yMin, int yMax) {
	double x;
    for (x = -200; x <= 200; x += 0.01) {
        int y = (int) sqrt(40000-(x*x));
        boxfill8(vram, xsize, c1, x + xMin, yMin + y, x + xMin, yMin + y);
        y = (int) -1*sqrt(40000-(x*x));
        boxfill8(vram, xsize, c1, x + xMin, yMin + y, x + xMin, yMin + y);
		
    }

    return;
}


void drawElementaryFunctionGraph(unsigned char *vram, int xsize, int c1, char *str, int size) {
	double x;

    boxfill8(vram, xsize, COL8_FFFFFF, 0, 350, xsize,351);
    boxfill8(vram, xsize, COL8_FFFFFF, 511, 0, 512,768);
    for (x = -500; x <= 500; x += 0.01) {
        int y = (int) -1*extractAndEvaluateFunction(str, x, size);
        boxfill8(vram, xsize, c1, x + 512, 350 + y, x + 512, 350 + y);
		
    }
	
    return;
}

void my_init_screen(char *vram, int x, int y)
{
	boxfill8(vram, x, 136,  0,     0,      x -  1, y - 1);
	drawElementaryFunctionGraph2(vram, x, COL8_FF00FF, 512, 0, 350, y - 1);
	drawElementaryFunctionGraph(vram, x, COL8_FF00FF, "sin(x)", 100);
	putfonts8_asc(vram, x, 361, 211, COL8_000000,"    ___          _   _    ______");
	putfonts8_asc(vram, x, 361, 226, COL8_000000,"   /---\\     ___| | | |__/      ;");
	putfonts8_asc(vram, x, 361, 241, COL8_000000,"  //   ;;   (____________password|");
	putfonts8_asc(vram, x, 361, 256, COL8_000000,"|---------|              \\______/");
	putfonts8_asc(vram, x, 361, 271, COL8_000000,"|  admin  |");
	putfonts8_asc(vram, x, 361, 286, COL8_000000,"|_________|");
	putfonts8_asc(vram, x, 361, 301, COL8_000000,"__        __         _     ___  ____ ");
	putfonts8_asc(vram, x, 361, 316, COL8_000000,"\\ \\      / /__  _ __| | __/ _ \\/ ___| ");
	putfonts8_asc(vram, x, 361, 331, COL8_000000," \\ \\ /\\ / / _ \\| '__| |/ / | | \\___ \\ ");
	putfonts8_asc(vram, x, 361, 346, COL8_000000,"  \\ V  V / (_) | |  |   <| |_| |___) |");
	putfonts8_asc(vram, x, 361, 361, COL8_000000,"   \\_/\\_/ \\___/|_|  |_|\\_|\\___/|____/");
	
	putfonts8_asc(vram, x, 360, 210, COL8_FFFFFF,"    ___          _   _    ______");
	putfonts8_asc(vram, x, 360, 225, COL8_FFFFFF,"   /---\\     ___| | | |__/      ;");
	putfonts8_asc(vram, x, 360, 240, COL8_FFFFFF,"  //   ;;   (____________password|");
	putfonts8_asc(vram, x, 360, 255, COL8_FFFFFF,"|---------|              \\______/");
	putfonts8_asc(vram, x, 360, 270, COL8_FFFFFF,"|  admin  |");
	putfonts8_asc(vram, x, 360, 285, COL8_FFFFFF,"|_________|");
	putfonts8_asc(vram, x, 360, 300, COL8_FFFFFF,"__        __         _     ___  ____ ");
	putfonts8_asc(vram, x, 360, 315, COL8_FFFFFF,"\\ \\      / /__  _ __| | __/ _ \\/ ___| ");
	putfonts8_asc(vram, x, 360, 330, COL8_FFFFFF," \\ \\ /\\ / / _ \\| '__| |/ / | | \\___ \\ ");
	putfonts8_asc(vram, x, 360, 345, COL8_FFFFFF,"  \\ V  V / (_) | |  |   <| |_| |___) |");
	putfonts8_asc(vram, x, 360, 360, COL8_FFFFFF,"   \\_/\\_/ \\___/|_|  |_|\\_|\\___/|____/");
	
	boxfill8(vram, x, COL8_C6C6C6,  480,480,565, 510);
	boxfill8(vram, x, COL8_FFFFFF,  480,480,565, 481);
	boxfill8(vram, x, COL8_FFFFFF,  480,480,481, 510);
	boxfill8(vram, x, COL8_000000,  565,480,566, 510);
	boxfill8(vram, x, COL8_000000,  480,510,565, 511);
	boxfill8(vram, x, COL8_848484,  565,480,565, 510);
	boxfill8(vram, x, COL8_848484,  480,510,565, 510);
	putfonts8_asc(vram, x, 500, 485, COL8_000000,"Login");
	
	drawElementaryFunctionGraph2(vram, x, COL8_FFFFFF, 0, 0, x - 1, y - 1);
	return;
}

void start_init_screen(char *vram, int x, int y)
{
	boxfill8(vram, x, COL8_C6C6C6,3, y - 110, 100, y - 36);
	boxfill8(vram, x, COL8_FFFFFF,3, y - 110, 100, y - 109);
	boxfill8(vram, x, COL8_FFFFFF,3, y - 110, 4, y - 35);
	boxfill8(vram, x, COL8_000000,99, y - 110, 100, y - 35);
	boxfill8(vram, x, COL8_000000,3, y - 36, 100, y - 35);
	
	
	putfonts8_asc(vram, x, 5, y - 60, COL8_000000,"shutdown");
	putfonts8_asc(vram, x, 5, y - 77, COL8_000000,"restart");
	putfonts8_asc(vram, x, 5, y - 94, COL8_000000,"apps");
	return;
}

void paint_init_screen(char *vram, int x, int y)
{
	boxfill8(vram, x, COL8_FFFFFF,  0,     0,      x -  1, y - 1);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);

	putfonts8_asc(vram, x, 12, 18, COL8_000000, "save");
	putfonts8_asc(vram, x, 10, y - 20, COL8_000000, "return");
	return;
}


void func_init_screen(char *vram, int x, int y, char* str, int size)
{
	boxfill8(vram, x, COL8_000000,  0,     0,      x -  1, y - 1);
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);

	putfonts8_asc(vram, x, 12, 18, COL8_000000, "save");
	putfonts8_asc(vram, x, 10, y - 20, COL8_000000, "return");
	
	drawElementaryFunctionGraph(vram, x, COL8_FF00FF, str, size);
	return;
}

void paint_init_screen2(char *vram, int x, int y)
{
boxfill8(vram, x, COL8_00FFFF, 0, y - 28, x - 1, y - 28);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 27, x - 1, y - 27);
boxfill8(vram, x, COL8_FFFFFF, 0, y - 26, x - 1, y - 1);
boxfill8(vram, x, COL8_FFFFFF, 3, y - 24, 59, y - 24);
boxfill8(vram, x, COL8_FFFFFF, 2, y - 24, 2, y - 4);
boxfill8(vram, x, COL8_00FFFF, 3, y - 4, 59, y - 4);
boxfill8(vram, x, COL8_00FFFF, 59, y - 23, 59, y - 5);
boxfill8(vram, x, COL8_00FFFF, 2, y - 3, 59, y - 3);
boxfill8(vram, x, COL8_00FFFF, 60, y - 24, 60, y - 3);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x - 4, y - 24);
boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y - 4);
boxfill8(vram, x, COL8_FFFFFF, x - 47, y - 3, x - 4, y - 3);
boxfill8(vram, x, COL8_FFFFFF, x - 3, y - 24, x - 3, y - 3);
	//my computer

	boxfill8(vram, x, COL8_C6C6C6, 10, 15, 45, 35);
	boxfill8(vram, x, COL8_00FFFF, 12, 17, 43, 33);
	boxfill8(vram, x, COL8_C6C6C6, 22, 35, 32, 45);
	boxfill8(vram, x, COL8_C6C6C6, 12, 45, 43, 47);
	
	putfonts8_asc(vram, x, 20, 50, COL8_000000, "my");
	putfonts8_asc(vram, x, 5, 66, COL8_000000, "computer");

	
	//note

	boxfill8(vram, x, COL8_C6C6C6, 10, 280, 33, 310);
	putfonts8_asc(vram, x, 8, 280, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 285, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 290, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 295, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 8, 300, COL8_C6C6C6, "-");
	putfonts8_asc(vram, x, 7, 320, COL8_000000, "note");

	//cmd

	boxfill8(vram, x, COL8_848484, 10, 99, 43, 123);
	boxfill8(vram, x, COL8_000000, 10, 100, 43, 123);
	putfonts8_asc(vram, x, 11, 102, COL8_FFFFFF, ">_");
	putfonts8_asc(vram, x, 10, 126, COL8_000000, "cmd");

	//VMware

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	boxfill8(vram, x, COL8_FF0000, 10, 160, 12, 182);
	boxfill8(vram, x, COL8_FF0000, 26, 160, 28, 182);
	boxfill8(vram, x, COL8_FF0000, 10, 180, 28, 182);
	
	boxfill8(vram, x, 203, 15, 155, 30, 157);
	boxfill8(vram, x, 203, 15, 155, 17, 177);
	boxfill8(vram, x, 203, 30, 155, 32, 177);
	boxfill8(vram, x, 203, 15, 175, 30, 177);

	boxfill8(vram, x, COL8_FF0000, 10, 160, 28, 162);
	
	putfonts8_asc(vram, x, 5, 186, COL8_000000, "VMware");

	putfonts8_asc(vram, x, 10, y - 20, COL8_00FFFF, "Start");

	//game

	boxfill8(vram, x, COL8_00FF00, 10, 210, 40, 240);
	putfonts8_asc(vram, x, 6, 250, COL8_000000, "game");
	return;
}



void init_screen(char *vram, int x, int y)
{
	boxfill8(vram, x, COL8_0000FF,  0,     0,      x -  1, y - 29);
	boxfill8(vram, x, COL8_00FFFF,  0,     y - 28, x -  1, y - 28);
	boxfill8(vram, x, COL8_FFFFFF,  0,     y - 27, x -  1, y - 27);
	boxfill8(vram, x, COL8_00FFFF,  0,     y - 26, x -  1, y -  1);

	boxfill8(vram, x, COL8_FFFFFF,  3,     y - 24, 59,     y - 24);
	boxfill8(vram, x, COL8_FFFFFF,  2,     y - 24,  2,     y -  4);
	boxfill8(vram, x, COL8_00FFFF,  3,     y -  4, 59,     y -  4);
	boxfill8(vram, x, COL8_00FFFF, 59,     y - 23, 59,     y -  5);
	boxfill8(vram, x, COL8_000000,  2,     y -  3, 59,     y -  3);
	boxfill8(vram, x, COL8_000000, 60,     y - 24, 60,     y -  3);

	boxfill8(vram, x, COL8_00FFFF, x - 47, y - 24, x -  4, y - 24);
	boxfill8(vram, x, COL8_00FFFF, x - 47, y - 23, x - 47, y -  4);
	boxfill8(vram, x, COL8_FFFFFF, x - 47, y -  3, x -  4, y -  3);
	boxfill8(vram, x, COL8_FFFFFF, x -  3, y - 24, x -  3, y -  3);

	boxfill8(vram, x, COL8_0000FF,  0,     0,      1,1);
	
	putfonts8_asc(vram, x, 360, 210, COL8_FFFF00," _   _              ___  ____  ");
	putfonts8_asc(vram, x, 360, 225, COL8_FFFF00,"| | | | __ _ _ __  / _ \\/ ___| ");
	putfonts8_asc(vram, x, 360, 240, COL8_FFFF00,"| |_| |/ _` | '_ \\| | | \\___ \\ ");
	putfonts8_asc(vram, x, 360, 255, COL8_FFFF00,"|  _  | (_| | | | | |_| |___) |");
	putfonts8_asc(vram, x, 360, 270, COL8_FFFF00,"|_| |_|\\__,_|_| |_|\\___/|____/ ");
	putfonts8_asc(vram, x, 401, 401, COL8_000000, "Han Operating System.");
	putfonts8_asc(vram, x, 400, 400, COL8_FFFFFF, "Han Operating System.");
	putfonts8_asc(vram, x, 10, 748, COL8_000000, "Start");
	putfonts8_asc(vram, x, 100, 748, COL8_000000, "Running:");
	putfonts8_asc(vram, x, 180, 748, COL8_000000, "|command|");
	putfonts8_asc(vram, x, 680, 748, COL8_000000, "|Area:China");
	putfonts8_asc(vram, x, 810, 748, COL8_000000, "|");
	putfonts8_asc(vram, x, 840, 748, COL8_000000, "|^|");

	return;
}

void putfont8(char *vram, int xsize, int x, int y, char c, char *font)
{
	int i;
	char *p, d /* data */;
	for (i = 0; i < 16; i++) {
		p = vram + (y + i) * xsize + x;
		d = font[i];
		if ((d & 0x80) != 0) { p[0] = c; }
		if ((d & 0x40) != 0) { p[1] = c; }
		if ((d & 0x20) != 0) { p[2] = c; }
		if ((d & 0x10) != 0) { p[3] = c; }
		if ((d & 0x08) != 0) { p[4] = c; }
		if ((d & 0x04) != 0) { p[5] = c; }
		if ((d & 0x02) != 0) { p[6] = c; }
		if ((d & 0x01) != 0) { p[7] = c; }
	}
	return;
}
void putfont8_ch(char *vram, int xsize, int x, int y, char c, char *font)
{
	int i;
	char *p, d;
	for (i = 0; i < 16; i++)
	{
		p = vram + (y + i) * xsize + x;
		d = font[i * 2];
		if ((d & 0x80) != 0) p[0] = c;
		if ((d & 0x40) != 0) p[1] = c;
		if ((d & 0x20) != 0) p[2] = c;
		if ((d & 0x10) != 0) p[3] = c;
		if ((d & 0x08) != 0) p[4] = c;
		if ((d & 0x04) != 0) p[5] = c;
		if ((d & 0x02) != 0) p[6] = c;
		if ((d & 0x01) != 0) p[7] = c;
	}
	return;
}

void putfont32(char *vram, int xsize, int x, int y, char c, char *font1, char *font2)
{
	int i,k,j,f;
	char *p, d ;
	j=0;
	p=vram+(y+j)*xsize+x;
	j++;
	//????
	for(i=0;i<16;i++)
	{
		for(k=0;k<8;k++)
		{
			if(font1[i]&(0x80>>k))
			{
				p[k+(i%2)*8]=c;
			}
		}
		for(k=0;k<8/2;k++)
		{
			f=p[k+(i%2)*8];
			p[k+(i%2)*8]=p[8-1-k+(i%2)*8];
			p[8-1-k+(i%2)*8]=f;
		}
		if(i%2)
		{
			p=vram+(y+j)*xsize+x;
			j++;
		}
	}
	//????
	for(i=0;i<16;i++)
	{
		for(k=0;k<8;k++)
		{
			if(font2[i]&(0x80>>k))
			{
				p[k+(i%2)*8]=c;
			}
		}
		for(k=0;k<8/2;k++)
		{
			f=p[k+(i%2)*8];
			p[k+(i%2)*8]=p[8-1-k+(i%2)*8];
			p[8-1-k+(i%2)*8]=f;
		}
		if(i%2)
		{
			p=vram+(y+j)*xsize+x;
			j++;
		}
	}
	return;
}


void putfonts8_asc(char *vram, int xsize, int x, int y, char c, unsigned char *s) //s�w��������??�I�ʒu�C�����Ȓ��ڎg�ps?�s?�掚�����I?�꘢?�Ǝ����G ��ascii??
{
	extern char hankaku[4096];
	struct TASK *task = task_now();
	char *nihongo = (char *) *((int *) 0x0fe8), *font;
	char *hzk = (char *) *((int *) 0x0fe8);
	int k, t;

	if (task->langmode == 0) {//��?�I�����W
		for (; *s != 0x00; s++) {
			putfont8(vram, xsize, x, y, c, hankaku + *s * 16);
			x += 8;
		}
	}
	if (task->langmode == 1) {//shift jis ���I����?��
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if ((0x81 <= *s && *s <= 0x9f) || (0xe0 <= *s && *s <= 0xfc)) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, nihongo + *s * 16);
				}
			} else {
				if (0x81 <= task->langbyte1 && task->langbyte1 <= 0x9f) {
					k = (task->langbyte1 - 0x81) * 2;
				} else {
					k = (task->langbyte1 - 0xe0) * 2 + 62;
				}
				if (0x40 <= *s && *s <= 0x7e) {
					t = *s - 0x40;
				} else if (0x80 <= *s && *s <= 0x9e) {
					t = *s - 0x80 + 63;
				} else {
					t = *s - 0x9f;
					k++;
				}
				task->langbyte1 = 0;
				font = nihongo + 256 * 16 + (k * 94 + t) * 32;
				putfont8(vram, xsize, x - 8, y, c, font     );	
				putfont8(vram, xsize, x    , y, c, font + 16);	/* �E���� */
			}
			x += 8;
		}
	}
		if(task->langmode == 2){
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if (0xa1 <= *s && *s <= 0xfe) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, hankaku + *s * 16);//????????hankaku?????
				}
			} else {
				k = task->langbyte1 - 0xa1;
				t = *s - 0xa1;
				task->langbyte1 = 0;
				font = nihongo + (k * 94 + t) * 32;
				putfont8_ch(vram,xsize,x-8,y,c,font);
				putfont8_ch(vram,xsize,x,y,c,font+1);
			}
			x += 8;
		}
	}
	if (task->langmode == 3) {
		for (; *s != 0x00; s++) {
			if (task->langbyte1 == 0) {
				if (0xa1 <= *s && *s <= 0xfe) {
					task->langbyte1 = *s;
				} else {
					putfont8(vram, xsize, x, y, c, hankaku + *s * 16);//????????hankaku?????
				}
			} else {
				k = task->langbyte1 - 0xa1;
				t = *s - 0xa1;
				task->langbyte1 = 0;
				font = nihongo + (k * 94 + t) * 32;
				putfont8_ch(vram,xsize,x-8,y,c,font);
				putfont8_ch(vram,xsize,x,y,c,font+1);
			}
			x += 8;
		}
	}
	return;
}

void init_mouse_cursor8(char *mouse, char bc)
/* �}�E�X�J�[�\���������i16x16�j */
{
	static char cursor[16][16] = {
	 "**..............",
	 "*O*.............",
	 "*OO*............",
	 "*OOO*...........",
	 "*OOOO*..........",
	 "*OOOOO*.........",
	 "*OOOOOO*........",
	 "*OOOOOOO*.......",
	 "*OOOOOOOO*......",
	 "*OOOOOOOOO*.....",
	 "*OOOOOO*****....",
	 "*OO**OO*........",
	 "*O*.*OO*........",
	 "**...*OO*.......",
	 "*....*OO*.......",
	 "......**........"

	};
	int x, y;

	for (y = 0; y < 16; y++) {
		for (x = 0; x < 16; x++) {
			if (cursor[y][x] == '*') {
				mouse[y * 16 + x] = COL8_000000;
			}
			if (cursor[y][x] == 'O') {
				mouse[y * 16 + x] = COL8_FFFFFF;
			}
			if (cursor[y][x] == '.') {
				mouse[y * 16 + x] = bc;
			}
		}
	}
	return;
}


void putblock8_8(char *vram, int vxsize, int pxsize,
	int pysize, int px0, int py0, char *buf, int bxsize)
{
	int x, y;
	for (y = 0; y < pysize; y++) {
		for (x = 0; x < pxsize; x++) {
			vram[(py0 + y) * vxsize + (px0 + x)] = buf[y * bxsize + x];
		}
	}
	return;
}
void putfonts_asc(char *vram, int xsize, int x, int y, char c, unsigned char *s)
{
	extern char hankaku[4096];
	for (; *s != 0x00; s++) {
		putfont8(vram, xsize, x, y, c, hankaku + *s * 16);
		x += 8;
	}
	return;

}
void font_init(unsigned char mode)
{
	struct MEMMAN *memman = (struct MEMMAN *) MEMMAN_ADDR;
	int *fat;
	int i;
	unsigned char *nihongo, *hzk;
	struct FILEINFO *finfo;
	extern char hankaku[4096];
    if( mode == 3)
	{
		//?��HZK16,���������W
		hzk = (unsigned char *) memman_alloc_4k(memman, 0x5d5d * 32);
		fat = (int *) memman_alloc_4k(memman, 4 * 2880);
		file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
		finfo = file_search("HZK16.fnt", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
		if (finfo != 0) {
		file_loadfile(finfo->clustno, finfo->size, hzk, fat, (char *) (ADR_DISKIMG + 0x003e00));
		} else {
			for (i = 0; i < 16 * 256; i++) {
			hzk[i] = hankaku[i]; /* �v�L����?�C?����??�O�ʓI�p������? */
			}
			for (i = 16 * 256; i < 0x5d5d * 32; i++) {
			hzk[i] = 0xff; /* ���������U�[0xff*/
			}
		}
		*((int *) 0x0fe8) = (int) hzk; //�p0xfe8����?�n��
		memman_free_4k(memman, (int) fat, 4 * 2880);
	}

	if( mode == 2)
	{
		nihongo = (unsigned char *) memman_alloc_4k(memman, 16 * 256 + 32 * 94 * 47);
		fat = (int *) memman_alloc_4k(memman, 4 * 2880);
		file_readfat(fat, (unsigned char *) (ADR_DISKIMG + 0x000200));
		finfo = file_search("nihongo.fnt", (struct FILEINFO *) (ADR_DISKIMG + 0x002600), 224);
		if (finfo != 0) {
			file_loadfile(finfo->clustno, finfo->size, nihongo, fat, (char *) (ADR_DISKIMG + 0x003e00));
		} else {
			for (i = 0; i < 16 * 256; i++) {
				nihongo[i] = hankaku[i]; /* �v�L����?�C?����??�O�ʓI�p������? */
			}
			for (i = 16 * 256; i < 16 * 256 + 32 * 94 * 47; i++) {
				nihongo[i] = 0xff; /* ���������U�[0xff*/
			}
		}
		*((int *) 0x0fd8) = (int) nihongo; //�p0xfe8����?�n��
		memman_free_4k(memman, (int) fat, 4 * 2880);
	}
}
